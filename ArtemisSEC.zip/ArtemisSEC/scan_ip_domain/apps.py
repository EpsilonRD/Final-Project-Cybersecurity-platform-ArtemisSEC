from django.apps import AppConfig


class ScanIpDomainConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'scan_ip_domain'
